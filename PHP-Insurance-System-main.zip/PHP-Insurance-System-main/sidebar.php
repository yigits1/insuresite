<header id="header" class="header d-flex align-items-center">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <h1>Gursoy Sigorta<span>.</span></h1>
      </a>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php#hero">Ana Sayfa</a></li>
          <li><a href="index.php#about">Hakkımızda</a></li>
          <li><a href="index.php#testimonials">Referanslar</a></li>
          <li><a href="index.php#team">Ekibimiz</a></li>
          <li><a href="blog.php">Bilgi Bankası</a></li>
          <li><a href="index.php#contact">Teklif Ver</a></li>
        </ul>
      </nav>
      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
    </div>
  </header>
