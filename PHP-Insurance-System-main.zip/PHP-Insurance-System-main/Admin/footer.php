<footer class="main-footer">
    <strong>Copyright &copy; 2024</strong> Tüm hakları saklıdır.
</footer>